#include<stdio.h>
#include<stdlib.h>

int numero,res=0;
int main()
      {
               printf("Digite um numero:");
               scanf("%d",&numero);
               res=numero*numero;
               printf("O quadrado do numero digitado foi :%d\n",res);
               system("pause");
               return 0;
               }
