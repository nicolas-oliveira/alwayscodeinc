#include<stdio.h>
#include<stdlib.h>

int lado,area=0;
int main()
      {
               printf("Digite o tamando do lado:");
               scanf("%d",&lado);
               area=(lado*lado);
               printf("A area do quadrado e:%d\n",area);
               system("pause");
               return 0;
               }
